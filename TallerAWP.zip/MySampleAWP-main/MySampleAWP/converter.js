const inputField = document.getElementById('input-temp');
const fromUnitField = document.getElementById('input-unit');

const toUnitField = document.getElementById('output-unit');

//resultado 
const outputField = document.getElementById('output-temp');

const form = document.getElementById('converter');

function convertTemp(value, fromUnit, toUnit) {
  if (fromUnit === 'c') {
    if (toUnit === 'f') {
      return value * 9 / 5 + 32; // C a F
    } else if (toUnit === 'k') {
      return value + 273.15; // C a K
    }
    return value; // C a C 
  }

  // si es Fahrenheit
  if (fromUnit === 'f') {
    if (toUnit === 'c') {
      return (value - 32) * 5 / 9; // F a C
    } else if (toUnit === 'k') {
      return (value + 459.67) * 5 / 9; // F a K
    }
    return value; // F a F
  }

  //si es Kelvin
  if (fromUnit === 'k') {
    if (toUnit === 'c') {
      return value - 273.15; // K a C
    } else if (toUnit === 'f') {
      return value * 9 / 5 - 459.67; // K a F
    }
    return value; // K a K
  }
  throw new Error('unidad no válida');
}

// evento que se activa cada vez que cambia un valor (input)
form.addEventListener('input', () => {
  const inputTemp = parseFloat(inputField.value); 
  const fromUnit = fromUnitField.value; 
  const toUnit = toUnitField.value; 

  const outputTemp = convertTemp(inputTemp, fromUnit, toUnit); 

  // resultado redondeado a 2 decimales
  outputField.value = (Math.round(outputTemp * 100) / 100) + ' ' + toUnit.toUpperCase();
});
